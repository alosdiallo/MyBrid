

Description of the file here :

  They contains no version number, so that they can be easily updated. This is 
done because removing a file needs to be done by sourceforge team.

commons-fileupload-1.0.jar
  It is now empty. It contains only a readme file ... explaining almost the same thing 
as here above. It should be removed, but I don't want to bother the sourceforge team
with that.


commons-fileupload.jar
  It contains the 1.1 version of commons-fileupload.jar.

commons-io.jar

  It contains currently (16 oct 2006) the 1.2 version of IO, so it's the 
commons-io-1.2.jar package.


etienne_sf
etienne_sf@sourceforge.net
